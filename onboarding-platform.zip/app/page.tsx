"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Building2, Shirt, Package, Backpack, Plus, Download, SettingsIcon, Users, BarChart3 } from "lucide-react"
import ItemRegistrationForm from "@/components/item-registration-form"
import ItemsList from "@/components/items-list"
import Dashboard from "@/components/dashboard"
import UserManagement from "@/components/user-management"
import Settings from "@/components/settings"

export type ItemType = "polo_shirt" | "jacket" | "backpack" | "other"

export interface Item {
  id: string
  name: string
  type: ItemType
  code: string
  description: string
  size?: string
  color: string
  material: string
  quantity: number
  unitPrice: number
  supplier: string
  dateAdded: string
  status: "active" | "inactive" | "discontinued"
  imageUrl?: string
  department: string
  assignedTo?: string
  notes?: string
}

export default function InstitutionalItemsRegistry() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [items, setItems] = useState<Item[]>([
    {
      id: "1",
      name: "Polo Corporativo Azul",
      type: "polo_shirt",
      code: "PC-001",
      description: "Polo corporativo con logo bordado",
      size: "M",
      color: "Azul Marino",
      material: "100% Algodón",
      quantity: 50,
      unitPrice: 25.99,
      supplier: "Textiles Corporativos SAC",
      dateAdded: "2024-01-15",
      status: "active",
      department: "Administración",
      assignedTo: "María González",
      notes: "Para eventos corporativos",
    },
    {
      id: "2",
      name: "Chaqueta Ejecutiva",
      type: "jacket",
      code: "CE-001",
      description: "Chaqueta formal para ejecutivos",
      size: "L",
      color: "Negro",
      material: "Poliéster Premium",
      quantity: 25,
      unitPrice: 89.99,
      supplier: "Uniformes Ejecutivos EIRL",
      dateAdded: "2024-01-20",
      status: "active",
      department: "Gerencia",
      notes: "Solo para nivel gerencial",
    },
    {
      id: "3",
      name: "Mochila Institucional",
      type: "backpack",
      code: "MI-001",
      description: "Mochila con logo institucional",
      color: "Gris",
      material: "Nylon resistente",
      quantity: 100,
      unitPrice: 45.5,
      supplier: "Accesorios Corporativos SA",
      dateAdded: "2024-01-25",
      status: "active",
      department: "Recursos Humanos",
      assignedTo: "Carlos Mendoza",
      notes: "Para nuevos empleados",
    },
  ])

  const addItem = (newItem: Omit<Item, "id" | "dateAdded">) => {
    const item: Item = {
      ...newItem,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split("T")[0],
    }
    setItems([...items, item])
  }

  const updateItem = (id: string, updatedItem: Partial<Item>) => {
    setItems(items.map((item) => (item.id === id ? { ...item, ...updatedItem } : item)))
  }

  const deleteItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id))
  }

  const getItemsByType = (type: ItemType) => {
    return items.filter((item) => item.type === type)
  }

  const getItemTypeIcon = (type: ItemType) => {
    switch (type) {
      case "polo_shirt":
        return <Shirt className="h-5 w-5" />
      case "jacket":
        return <Package className="h-5 w-5" />
      case "backpack":
        return <Backpack className="h-5 w-5" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  const getItemTypeLabel = (type: ItemType) => {
    switch (type) {
      case "polo_shirt":
        return "Polos"
      case "jacket":
        return "Chaquetas"
      case "backpack":
        return "Mochilas"
      default:
        return "Otros"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Building2 className="h-8 w-8 text-blue-600" />
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Sistema de Registro</h1>
                  <p className="text-sm text-gray-600">Artículos de Identificación Institucional</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-600 border-green-600">
                {items.length} Artículos Registrados
              </Badge>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 lg:w-auto lg:grid-cols-7">
            <TabsTrigger value="dashboard" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="register" className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Registrar</span>
            </TabsTrigger>
            <TabsTrigger value="polos" className="flex items-center space-x-2">
              <Shirt className="h-4 w-4" />
              <span className="hidden sm:inline">Polos</span>
            </TabsTrigger>
            <TabsTrigger value="jackets" className="flex items-center space-x-2">
              <Package className="h-4 w-4" />
              <span className="hidden sm:inline">Chaquetas</span>
            </TabsTrigger>
            <TabsTrigger value="backpacks" className="flex items-center space-x-2">
              <Backpack className="h-4 w-4" />
              <span className="hidden sm:inline">Mochilas</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Usuarios</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <SettingsIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Config</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard">
            <Dashboard items={items} />
          </TabsContent>

          {/* Registration Tab */}
          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Plus className="h-6 w-6 text-blue-600" />
                  <span>Registrar Nuevo Artículo</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ItemRegistrationForm onSubmit={addItem} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Polo Shirts Tab */}
          <TabsContent value="polos">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shirt className="h-6 w-6 text-blue-600" />
                  <span>Polos Corporativos</span>
                  <Badge variant="secondary">{getItemsByType("polo_shirt").length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ItemsList
                  items={getItemsByType("polo_shirt")}
                  onUpdate={updateItem}
                  onDelete={deleteItem}
                  itemType="polo_shirt"
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Jackets Tab */}
          <TabsContent value="jackets">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Package className="h-6 w-6 text-blue-600" />
                  <span>Chaquetas Institucionales</span>
                  <Badge variant="secondary">{getItemsByType("jacket").length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ItemsList
                  items={getItemsByType("jacket")}
                  onUpdate={updateItem}
                  onDelete={deleteItem}
                  itemType="jacket"
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backpacks Tab */}
          <TabsContent value="backpacks">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Backpack className="h-6 w-6 text-blue-600" />
                  <span>Mochilas Corporativas</span>
                  <Badge variant="secondary">{getItemsByType("backpack").length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ItemsList
                  items={getItemsByType("backpack")}
                  onUpdate={updateItem}
                  onDelete={deleteItem}
                  itemType="backpack"
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <UserManagement />
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Settings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
