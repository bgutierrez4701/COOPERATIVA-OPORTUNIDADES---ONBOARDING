"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, UserPlus, BarChart3, Eye, Trash2, CheckCircle, Clock, Info } from "lucide-react"
import { supabase, isSupabaseConfigured, type Profile } from "@/lib/supabase"

export default function AdminPanel() {
  const [users, setUsers] = useState<Profile[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  // Form states
  const [newUserEmail, setNewUserEmail] = useState("")
  const [newUserName, setNewUserName] = useState("")
  const [newUserPassword, setNewUserPassword] = useState("")

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    if (!isSupabaseConfigured) {
      // Demo mode - show mock users
      const mockUsers: Profile[] = [
        {
          id: "demo-admin-id",
          email: "admin@coopoportunidades.com",
          full_name: "Administrador Sistema",
          role: "admin",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        {
          id: "demo-user-id",
          email: "asesor@coopoportunidades.com",
          full_name: "María González - Asesor de Crédito",
          role: "user",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ]
      setUsers(mockUsers)
      return
    }

    try {
      const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

      if (error) throw error
      setUsers(data || [])
    } catch (error) {
      console.error("Error fetching users:", error)
    }
  }

  const createUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess("")

    if (!isSupabaseConfigured) {
      setError("Función no disponible en modo demo. Configura Supabase para usar esta funcionalidad.")
      setLoading(false)
      return
    }

    try {
      // Crear usuario en Supabase Auth
      const { data, error } = await supabase.auth.admin.createUser({
        email: newUserEmail,
        password: newUserPassword,
        user_metadata: {
          full_name: newUserName,
        },
        email_confirm: true,
      })

      if (error) throw error

      // Actualizar el perfil con el nombre completo
      if (data.user) {
        await supabase.from("profiles").update({ full_name: newUserName }).eq("id", data.user.id)
      }

      setSuccess("Nuevo asesor creado exitosamente")
      setNewUserEmail("")
      setNewUserName("")
      setNewUserPassword("")
      await fetchUsers()
    } catch (error: any) {
      setError(error.message || "Error al crear asesor")
    } finally {
      setLoading(false)
    }
  }

  const deleteUser = async (userId: string) => {
    if (!confirm("¿Estás seguro de que quieres eliminar este asesor?")) return

    if (!isSupabaseConfigured) {
      setError("Función no disponible en modo demo. Configura Supabase para usar esta funcionalidad.")
      return
    }

    try {
      const { error } = await supabase.auth.admin.deleteUser(userId)
      if (error) throw error

      setSuccess("Asesor eliminado exitosamente")
      await fetchUsers()
    } catch (error: any) {
      setError(error.message || "Error al eliminar asesor")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-primary-500 mb-2">Panel de Administración</h1>
        <p className="text-gray-600">Gestiona asesores de crédito y supervisa el progreso del onboarding</p>
      </div>

      {!isSupabaseConfigured && (
        <Alert className="mb-6">
          <Info className="h-4 w-4" />
          <AlertDescription>
            <strong>Modo Demo:</strong> Algunas funciones están limitadas. Configura Supabase para acceso completo.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>Asesores</span>
          </TabsTrigger>
          <TabsTrigger value="create" className="flex items-center space-x-2">
            <UserPlus className="h-4 w-4" />
            <span>Crear Asesor</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center space-x-2">
            <BarChart3 className="h-4 w-4" />
            <span>Estadísticas</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Asesores de Crédito</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-semibold">{user.full_name || "Sin nombre"}</h3>
                      <p className="text-sm text-gray-600">{user.email}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                          {user.role === "admin" ? "Administrador" : "Asesor de Crédito"}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          Creado: {new Date(user.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      {user.role !== "admin" && (
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteUser(user.id)}
                          disabled={!isSupabaseConfigured}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Crear Nuevo Asesor de Crédito</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={createUser} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre Completo</Label>
                  <Input
                    id="name"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="María González Pérez"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Correo Corporativo</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="maria.gonzalez@coopoportunidades.com"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña Temporal</Label>
                  <Input
                    id="password"
                    type="password"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    minLength={6}
                    required
                  />
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>{success}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  className="w-full bg-primary-500 hover:bg-primary-600"
                  disabled={loading || !isSupabaseConfigured}
                >
                  {loading ? "Creando asesor..." : "Crear Asesor de Crédito"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <Users className="h-8 w-8 text-primary-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-primary-600">{users.length}</div>
                <div className="text-sm text-gray-600">Total Asesores</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-600">0</div>
                <div className="text-sm text-gray-600">Capacitaciones Completadas</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <Clock className="h-8 w-8 text-secondary-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-secondary-600">{users.length}</div>
                <div className="text-sm text-gray-600">En Proceso de Onboarding</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
