"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CreditCard, DollarSign, Calendar, TrendingUp, AlertCircle, CheckCircle, Calculator } from "lucide-react"

interface CreditsSectionProps {
  onComplete: () => void
}

export default function CreditsSection({ onComplete }: CreditsSectionProps) {
  const handleComplete = () => {
    onComplete()
  }

  const creditTypes = [
    {
      name: "Crédito de Capital de Trabajo",
      description: "Para financiar operaciones diarias del negocio",
      amount: "$500 - $5,000",
      term: "3-12 meses",
      rate: "18-24% anual",
      icon: DollarSign,
      color: "text-primary-600",
    },
    {
      name: "Crédito para Activos Fijos",
      description: "Para compra de equipos, maquinaria o infraestructura",
      amount: "$1,000 - $10,000",
      term: "6-24 meses",
      rate: "20-26% anual",
      icon: TrendingUp,
      color: "text-secondary-600",
    },
    {
      name: "Crédito de Emergencia",
      description: "Para situaciones imprevistas o urgentes",
      amount: "$200 - $2,000",
      term: "1-6 meses",
      rate: "22-28% anual",
      icon: AlertCircle,
      color: "text-red-600",
    },
    {
      name: "Crédito Estacional",
      description: "Para negocios con ciclos estacionales",
      amount: "$800 - $8,000",
      term: "3-18 meses",
      rate: "19-25% anual",
      icon: Calendar,
      color: "text-green-600",
    },
  ]

  const factors = [
    {
      factor: "Historial Crediticio",
      weight: 30,
      description: "Registro de pagos anteriores y comportamiento financiero",
    },
    {
      factor: "Capacidad de Pago",
      weight: 25,
      description: "Ingresos y flujo de efectivo del negocio",
    },
    {
      factor: "Garantías",
      weight: 20,
      description: "Respaldo del grupo y garantías adicionales",
    },
    {
      factor: "Experiencia del Negocio",
      weight: 15,
      description: "Tiempo en el mercado y conocimiento del sector",
    },
    {
      factor: "Estabilidad del Grupo",
      weight: 10,
      description: "Cohesión y compromiso del grupo solidario",
    },
  ]

  const process = [
    {
      step: 1,
      title: "Solicitud",
      description: "Presentar documentos y llenar formularios",
      duration: "1-2 días",
    },
    {
      step: 2,
      title: "Evaluación",
      description: "Análisis de capacidad de pago y riesgo",
      duration: "3-5 días",
    },
    {
      step: 3,
      title: "Aprobación",
      description: "Decisión del comité de crédito",
      duration: "1-2 días",
    },
    {
      step: 4,
      title: "Desembolso",
      description: "Entrega del dinero al grupo",
      duration: "1 día",
    },
  ]

  const tips = [
    {
      category: "Antes de Solicitar",
      advice: [
        "Define claramente el propósito del crédito",
        "Calcula tu capacidad de pago real",
        "Prepara toda la documentación necesaria",
        "Consulta con tu grupo sobre el monto",
      ],
    },
    {
      category: "Durante el Proceso",
      advice: [
        "Sé honesto en toda la información",
        "Responde rápidamente a solicitudes",
        "Mantén comunicación con tu asesor",
        "Coordina con los miembros del grupo",
      ],
    },
    {
      category: "Después del Desembolso",
      advice: [
        "Usa el dinero solo para el propósito acordado",
        "Lleva un registro detallado de gastos",
        "Paga puntualmente todas las cuotas",
        "Comunica cualquier dificultad temprano",
      ],
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Qué son los Créditos?</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Los créditos son herramientas financieras que te permiten acceder a capital para hacer crecer tu negocio, con
          la responsabilidad de devolverlo en condiciones acordadas.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-xl text-center text-primary-900">
            El Crédito: Tu Aliado para el Crecimiento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-primary-800">
            Un crédito bien utilizado puede ser la diferencia entre mantener tu negocio estable y llevarlo al siguiente
            nivel. La clave está en entender cómo funciona y usarlo responsablemente.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {creditTypes.map((credit, index) => {
          const Icon = credit.icon
          return (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Icon className={`h-6 w-6 ${credit.color}`} />
                  <div>
                    <CardTitle className="text-lg">{credit.name}</CardTitle>
                    <p className="text-sm text-gray-600">{credit.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="font-semibold text-sm text-gray-700">Monto</div>
                    <div className="text-xs text-gray-600">{credit.amount}</div>
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-gray-700">Plazo</div>
                    <div className="text-xs text-gray-600">{credit.term}</div>
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-gray-700">Tasa</div>
                    <div className="text-xs text-gray-600">{credit.rate}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Factores de Evaluación Crediticia</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {factors.map((factor, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <h4 className="font-semibold">{factor.factor}</h4>
                  <Badge variant="outline">{factor.weight}%</Badge>
                </div>
                <p className="text-sm text-gray-600">{factor.description}</p>
                <Progress value={factor.weight * 3.33} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Proceso de Solicitud de Crédito</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {process.map((item, index) => (
              <div key={index} className="text-center">
                <div className="bg-primary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-primary-600 font-bold">{item.step}</span>
                </div>
                <h4 className="font-semibold mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                <Badge variant="secondary" className="text-xs">
                  {item.duration}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tips.map((tipCategory, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="text-lg">{tipCategory.category}</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {tipCategory.advice.map((tip, tipIndex) => (
                  <li key={tipIndex} className="flex items-start space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                    <span className="text-sm text-gray-700">{tip}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center">
          <CardContent className="p-6">
            <Calculator className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-primary-600 mb-1">5-7 días</div>
            <div className="text-sm text-gray-600">Tiempo promedio de aprobación</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <CreditCard className="h-8 w-8 text-secondary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-secondary-600 mb-1">95%</div>
            <div className="text-sm text-gray-600">Tasa de aprobación grupal</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <TrendingUp className="h-8 w-8 text-primary-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-primary-600 mb-1">$2,500</div>
            <div className="text-sm text-gray-600">Monto promedio por socio</div>
          </CardContent>
        </Card>
      </div>

      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-primary-900 mb-2">🎉 ¡Felicitaciones!</h3>
          <p className="text-primary-800 mb-4">
            Has completado exitosamente todos los módulos del proceso de incorporación de COOPERATIVA OPORTUNIDADES.
            Ahora tienes las herramientas y conocimientos necesarios para ser un socio exitoso.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="text-center">
              <h4 className="font-semibold text-primary-800">Lo que has aprendido:</h4>
              <ul className="text-sm text-primary-700 mt-2">
                <li>• Principios y valores cooperativos</li>
                <li>• Metodología de créditos grupales</li>
                <li>• Habilidades blandas esenciales</li>
                <li>• Técnicas de negociación y trabajo en equipo</li>
              </ul>
            </div>
            <div className="text-center">
              <h4 className="font-semibold text-primary-800">Próximos pasos:</h4>
              <ul className="text-sm text-primary-700 mt-2">
                <li>• Formar o unirte a un grupo</li>
                <li>• Solicitar tu primer crédito</li>
                <li>• Participar en actividades cooperativas</li>
                <li>• Aplicar lo aprendido en tu negocio</li>
              </ul>
            </div>
          </div>
          <Button onClick={handleComplete} size="lg" className="bg-primary-600 hover:bg-primary-700">
            Finalizar Capacitación
          </Button>
        </div>
      </div>
    </div>
  )
}
