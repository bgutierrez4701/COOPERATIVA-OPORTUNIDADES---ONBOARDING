"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { BarChart3, TrendingUp, Package, DollarSign, Shirt, Backpack, AlertTriangle, Users } from "lucide-react"
import type { Item } from "@/app/page"

interface DashboardProps {
  items: Item[]
}

export default function Dashboard({ items }: DashboardProps) {
  const totalItems = items.length
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0)
  const totalValue = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
  const activeItems = items.filter((item) => item.status === "active").length

  const poloShirts = items.filter((item) => item.type === "polo_shirt")
  const jackets = items.filter((item) => item.type === "jacket")
  const backpacks = items.filter((item) => item.type === "backpack")

  const lowStockItems = items.filter((item) => item.quantity < 10)
  const recentItems = items
    .sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime())
    .slice(0, 5)

  const departmentStats = items.reduce(
    (acc, item) => {
      acc[item.department] = (acc[item.department] || 0) + item.quantity
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Artículos</p>
                <p className="text-3xl font-bold text-blue-600">{totalItems}</p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
            <div className="mt-4">
              <Badge variant="outline" className="text-green-600 border-green-600">
                {activeItems} Activos
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Cantidad Total</p>
                <p className="text-3xl font-bold text-green-600">{totalQuantity}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-green-600" />
            </div>
            <div className="mt-4">
              <Badge variant="outline" className="text-orange-600 border-orange-600">
                {lowStockItems.length} Stock Bajo
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Valor Total</p>
                <p className="text-3xl font-bold text-purple-600">S/ {totalValue.toFixed(2)}</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
            <div className="mt-4">
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                Inventario
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Departamentos</p>
                <p className="text-3xl font-bold text-orange-600">{Object.keys(departmentStats).length}</p>
              </div>
              <Users className="h-8 w-8 text-orange-600" />
            </div>
            <div className="mt-4">
              <Badge variant="outline" className="text-purple-600 border-purple-600">
                Activos
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shirt className="h-5 w-5 text-blue-600" />
              <span>Polos / Camisas</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total</span>
                <Badge variant="outline">{poloShirts.length} artículos</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Cantidad</span>
                <span className="font-semibold">
                  {poloShirts.reduce((sum, item) => sum + item.quantity, 0)} unidades
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Valor</span>
                <span className="font-semibold">
                  S/ {poloShirts.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0).toFixed(2)}
                </span>
              </div>
              <Progress value={(poloShirts.length / totalItems) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5 text-green-600" />
              <span>Chaquetas / Sacos</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total</span>
                <Badge variant="outline">{jackets.length} artículos</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Cantidad</span>
                <span className="font-semibold">{jackets.reduce((sum, item) => sum + item.quantity, 0)} unidades</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Valor</span>
                <span className="font-semibold">
                  S/ {jackets.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0).toFixed(2)}
                </span>
              </div>
              <Progress value={(jackets.length / totalItems) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Backpack className="h-5 w-5 text-purple-600" />
              <span>Mochilas / Bolsos</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Total</span>
                <Badge variant="outline">{backpacks.length} artículos</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Cantidad</span>
                <span className="font-semibold">
                  {backpacks.reduce((sum, item) => sum + item.quantity, 0)} unidades
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Valor</span>
                <span className="font-semibold">
                  S/ {backpacks.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0).toFixed(2)}
                </span>
              </div>
              <Progress value={(backpacks.length / totalItems) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts and Recent Items */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <span>Alertas de Stock Bajo</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {lowStockItems.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No hay alertas de stock bajo</p>
            ) : (
              <div className="space-y-3">
                {lowStockItems.slice(0, 5).map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-600">{item.code}</p>
                    </div>
                    <Badge variant="destructive">{item.quantity} unidades</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <span>Artículos Recientes</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-gray-600">{item.department}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">{item.quantity}</Badge>
                    <p className="text-sm text-gray-500 mt-1">{new Date(item.dateAdded).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Department Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Distribución por Departamento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(departmentStats).map(([department, quantity]) => (
              <div key={department} className="p-4 bg-gray-50 rounded-lg">
                <p className="font-medium">{department}</p>
                <p className="text-2xl font-bold text-blue-600">{quantity}</p>
                <p className="text-sm text-gray-600">unidades</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
