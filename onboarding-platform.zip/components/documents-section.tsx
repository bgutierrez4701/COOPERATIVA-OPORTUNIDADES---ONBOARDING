"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, FileText, Download, Eye, CheckCircle } from "lucide-react"

interface DocumentsSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function DocumentsSection({ onComplete, onNext }: DocumentsSectionProps) {
  const [documents, setDocuments] = useState([
    {
      id: 1,
      title: "Solicitud de Ingreso",
      description: "Formulario oficial para ser socio de la cooperativa",
      type: "Requerido",
      status: "pending",
      signed: false,
      reviewed: false,
    },
    {
      id: 2,
      title: "Estatutos de la Cooperativa",
      description: "Normas y reglamentos que rigen nuestra cooperativa",
      type: "Requerido",
      status: "pending",
      signed: false,
      reviewed: false,
    },
    {
      id: 3,
      title: "Reglamento Interno",
      description: "Políticas y procedimientos internos",
      type: "Requerido",
      status: "pending",
      signed: false,
      reviewed: false,
    },
    {
      id: 4,
      title: "Código de Ética Cooperativa",
      description: "Principios y valores cooperativos",
      type: "Requerido",
      status: "pending",
      signed: false,
      reviewed: false,
    },
    {
      id: 5,
      title: "Información de Servicios",
      description: "Catálogo de servicios disponibles para socios",
      type: "Informativo",
      status: "pending",
      signed: false,
      reviewed: false,
    },
  ])

  const handleReview = (docId: number) => {
    setDocuments((docs) => docs.map((doc) => (doc.id === docId ? { ...doc, reviewed: true } : doc)))
  }

  const handleSign = (docId: number) => {
    setDocuments((docs) => docs.map((doc) => (doc.id === docId ? { ...doc, signed: true, status: "completed" } : doc)))
  }

  const requiredDocs = documents.filter((doc) => doc.type === "Requerido")
  const completedRequired = requiredDocs.filter((doc) => doc.signed).length
  const canContinue = completedRequired === requiredDocs.length

  const handleContinue = () => {
    if (canContinue) {
      onComplete()
      onNext()
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Documentos Cooperativos</h2>
        <p className="text-lg text-gray-600">
          Revisa y firma los documentos necesarios para formalizar tu membresía cooperativa
        </p>
      </div>

      <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-primary-900">Progreso de Documentos</h3>
            <p className="text-sm text-primary-700">
              {completedRequired} de {requiredDocs.length} documentos requeridos completados
            </p>
          </div>
          <Badge variant={canContinue ? "default" : "secondary"}>{canContinue ? "Completo" : "En Progreso"}</Badge>
        </div>
      </div>

      <div className="space-y-4">
        {documents.map((doc) => (
          <Card
            key={doc.id}
            className={`transition-all ${doc.signed ? "border-green-200 bg-green-50" : "border-gray-200"}`}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="mt-1">
                    {doc.signed ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : (
                      <FileText className="h-6 w-6 text-gray-400" />
                    )}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{doc.title}</CardTitle>
                    <CardDescription className="mt-1">{doc.description}</CardDescription>
                  </div>
                </div>
                <Badge
                  variant={doc.type === "Requerido" ? "destructive" : doc.type === "Opcional" ? "secondary" : "default"}
                >
                  {doc.type}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`reviewed-${doc.id}`}
                      checked={doc.reviewed}
                      onCheckedChange={() => handleReview(doc.id)}
                    />
                    <label htmlFor={`reviewed-${doc.id}`} className="text-sm">
                      He leído este documento
                    </label>
                  </div>
                  {doc.type === "Requerido" && (
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`signed-${doc.id}`}
                        checked={doc.signed}
                        onCheckedChange={() => handleSign(doc.id)}
                        disabled={!doc.reviewed}
                      />
                      <label htmlFor={`signed-${doc.id}`} className="text-sm">
                        Acepto y firmo
                      </label>
                    </div>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    Ver
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Descargar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!canContinue && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800 text-sm">
            ⚠️ Debes completar todos los documentos requeridos antes de continuar.
          </p>
        </div>
      )}

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8" disabled={!canContinue}>
          Continuar al Siguiente Paso
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
