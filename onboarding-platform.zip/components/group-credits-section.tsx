"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Users, Shield, TrendingUp, CheckCircle, AlertCircle, DollarSign } from "lucide-react"

interface GroupCreditsSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function GroupCreditsSection({ onComplete, onNext }: GroupCreditsSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const benefits = [
    {
      title: "Garantía Solidaria",
      description: "El grupo respalda cada crédito, reduciendo riesgos para todos",
      icon: Shield,
      color: "text-primary-600",
    },
    {
      title: "Tasas Preferenciales",
      description: "Mejores condiciones financieras por el respaldo grupal",
      icon: DollarSign,
      color: "text-secondary-600",
    },
    {
      title: "Apoyo Mutuo",
      description: "Los miembros se apoyan en el crecimiento de sus negocios",
      icon: Users,
      color: "text-primary-600",
    },
    {
      title: "Crecimiento Progresivo",
      description: "Montos de crédito que aumentan con el buen historial grupal",
      icon: TrendingUp,
      color: "text-secondary-600",
    },
  ]

  const requirements = [
    "Formar un grupo de 3 a 8 personas",
    "Todos los miembros deben tener un negocio o actividad económica",
    "Residir en la misma comunidad o zona",
    "Comprometerse con la metodología solidaria",
    "Participar en capacitaciones grupales",
  ]

  const process = [
    {
      step: 1,
      title: "Formación del Grupo",
      description: "Reúne a personas de confianza con negocios similares",
    },
    {
      step: 2,
      title: "Capacitación Inicial",
      description: "Todos los miembros reciben formación en metodología grupal",
    },
    {
      step: 3,
      title: "Evaluación Grupal",
      description: "Análisis de la viabilidad y compromiso del grupo",
    },
    {
      step: 4,
      title: "Primer Desembolso",
      description: "Entrega del primer crédito a todos los miembros",
    },
    {
      step: 5,
      title: "Seguimiento",
      description: "Acompañamiento continuo y reuniones grupales regulares",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Qué son los Créditos Grupales?</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Una metodología innovadora donde un grupo de personas se respalda mutuamente para acceder a financiamiento y
          crecer juntos económicamente.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-2xl text-center text-primary-900">
            La Fuerza de la Solidaridad Financiera
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-primary-800 text-lg">
            Los créditos grupales se basan en la confianza mutua y el compromiso compartido. Cada miembro del grupo es
            responsable no solo de su propio crédito, sino también del éxito de todo el grupo.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <CheckCircle className="h-6 w-6 text-green-600" />
              <span>Beneficios Principales</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {benefits.map((benefit, index) => {
                const Icon = benefit.icon
                return (
                  <div key={index} className="flex items-start space-x-3">
                    <Icon className={`h-6 w-6 ${benefit.color} mt-1`} />
                    <div>
                      <h4 className="font-semibold">{benefit.title}</h4>
                      <p className="text-sm text-gray-600">{benefit.description}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <AlertCircle className="h-6 w-6 text-secondary-600" />
              <span>Requisitos del Grupo</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {requirements.map((requirement, index) => (
                <li key={index} className="flex items-start space-x-3">
                  <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-center">Proceso de Crédito Grupal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {process.map((item, index) => (
              <div key={index} className="text-center">
                <div className="bg-primary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-primary-600 font-bold">{item.step}</span>
                </div>
                <h4 className="font-semibold mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary-600 mb-2">3-8</div>
            <div className="text-gray-600">Miembros por grupo</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-secondary-600 mb-2">95%</div>
            <div className="text-gray-600">Tasa de éxito</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary-600 mb-2">$500-$5K</div>
            <div className="text-gray-600">Rango de montos</div>
          </CardContent>
        </Card>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-yellow-800 mb-3">🤝 Principios de la Metodología Grupal</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-yellow-800">Responsabilidad Compartida</h4>
            <p className="text-sm text-yellow-700">Todos los miembros son responsables del éxito del grupo</p>
          </div>
          <div>
            <h4 className="font-semibold text-yellow-800">Transparencia Total</h4>
            <p className="text-sm text-yellow-700">Información abierta sobre el estado de cada miembro</p>
          </div>
          <div>
            <h4 className="font-semibold text-yellow-800">Apoyo Mutuo</h4>
            <p className="text-sm text-yellow-700">Los miembros se ayudan en momentos difíciles</p>
          </div>
          <div>
            <h4 className="font-semibold text-yellow-800">Crecimiento Conjunto</h4>
            <p className="text-sm text-yellow-700">El éxito individual beneficia a todo el grupo</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Desarrollar Habilidades Blandas
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
