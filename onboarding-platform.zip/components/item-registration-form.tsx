"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Save, RefreshCw, Shirt, Package, Backpack } from "lucide-react"
import type { Item, ItemType } from "@/app/page"

interface ItemRegistrationFormProps {
  onSubmit: (item: Omit<Item, "id" | "dateAdded">) => void
  initialData?: Partial<Item>
  isEditing?: boolean
}

export default function ItemRegistrationForm({ onSubmit, initialData, isEditing = false }: ItemRegistrationFormProps) {
  const [formData, setFormData] = useState({
    name: initialData?.name || "",
    type: initialData?.type || ("polo_shirt" as ItemType),
    code: initialData?.code || "",
    description: initialData?.description || "",
    size: initialData?.size || "",
    color: initialData?.color || "",
    material: initialData?.material || "",
    quantity: initialData?.quantity || 0,
    unitPrice: initialData?.unitPrice || 0,
    supplier: initialData?.supplier || "",
    status: initialData?.status || ("active" as const),
    department: initialData?.department || "",
    assignedTo: initialData?.assignedTo || "",
    notes: initialData?.notes || "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.name.trim()) newErrors.name = "El nombre es requerido"
    if (!formData.code.trim()) newErrors.code = "El código es requerido"
    if (!formData.color.trim()) newErrors.color = "El color es requerido"
    if (!formData.material.trim()) newErrors.material = "El material es requerido"
    if (formData.quantity <= 0) newErrors.quantity = "La cantidad debe ser mayor a 0"
    if (formData.unitPrice <= 0) newErrors.unitPrice = "El precio debe ser mayor a 0"
    if (!formData.supplier.trim()) newErrors.supplier = "El proveedor es requerido"
    if (!formData.department.trim()) newErrors.department = "El departamento es requerido"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate API call
      onSubmit(formData)

      if (!isEditing) {
        // Reset form after successful submission
        setFormData({
          name: "",
          type: "polo_shirt",
          code: "",
          description: "",
          size: "",
          color: "",
          material: "",
          quantity: 0,
          unitPrice: 0,
          supplier: "",
          status: "active",
          department: "",
          assignedTo: "",
          notes: "",
        })
      }
    } catch (error) {
      console.error("Error submitting form:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: keyof typeof formData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const getTypeIcon = (type: ItemType) => {
    switch (type) {
      case "polo_shirt":
        return <Shirt className="h-4 w-4" />
      case "jacket":
        return <Package className="h-4 w-4" />
      case "backpack":
        return <Backpack className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Información Básica</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Nombre del Artículo *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Ej: Polo Corporativo Azul"
                className={errors.name ? "border-red-500" : ""}
              />
              {errors.name && <p className="text-sm text-red-500 mt-1">{errors.name}</p>}
            </div>

            <div>
              <Label htmlFor="type">Tipo de Artículo *</Label>
              <Select value={formData.type} onValueChange={(value: ItemType) => handleInputChange("type", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="polo_shirt">
                    <div className="flex items-center space-x-2">
                      <Shirt className="h-4 w-4" />
                      <span>Polo / Camisa</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="jacket">
                    <div className="flex items-center space-x-2">
                      <Package className="h-4 w-4" />
                      <span>Chaqueta / Saco</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="backpack">
                    <div className="flex items-center space-x-2">
                      <Backpack className="h-4 w-4" />
                      <span>Mochila / Bolso</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="other">
                    <div className="flex items-center space-x-2">
                      <Package className="h-4 w-4" />
                      <span>Otro</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="code">Código del Artículo *</Label>
              <Input
                id="code"
                value={formData.code}
                onChange={(e) => handleInputChange("code", e.target.value)}
                placeholder="Ej: PC-001"
                className={errors.code ? "border-red-500" : ""}
              />
              {errors.code && <p className="text-sm text-red-500 mt-1">{errors.code}</p>}
            </div>

            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Descripción detallada del artículo"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Physical Specifications */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Especificaciones Físicas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="size">Talla / Tamaño</Label>
              <Select value={formData.size} onValueChange={(value) => handleInputChange("size", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar talla" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="XS">XS - Extra Pequeño</SelectItem>
                  <SelectItem value="S">S - Pequeño</SelectItem>
                  <SelectItem value="M">M - Mediano</SelectItem>
                  <SelectItem value="L">L - Grande</SelectItem>
                  <SelectItem value="XL">XL - Extra Grande</SelectItem>
                  <SelectItem value="XXL">XXL - Doble Extra Grande</SelectItem>
                  <SelectItem value="Único">Talla Única</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="color">Color *</Label>
              <Input
                id="color"
                value={formData.color}
                onChange={(e) => handleInputChange("color", e.target.value)}
                placeholder="Ej: Azul Marino, Negro, Gris"
                className={errors.color ? "border-red-500" : ""}
              />
              {errors.color && <p className="text-sm text-red-500 mt-1">{errors.color}</p>}
            </div>

            <div>
              <Label htmlFor="material">Material *</Label>
              <Input
                id="material"
                value={formData.material}
                onChange={(e) => handleInputChange("material", e.target.value)}
                placeholder="Ej: 100% Algodón, Poliéster, Nylon"
                className={errors.material ? "border-red-500" : ""}
              />
              {errors.material && <p className="text-sm text-red-500 mt-1">{errors.material}</p>}
            </div>

            <div>
              <Label htmlFor="status">Estado</Label>
              <Select
                value={formData.status}
                onValueChange={(value: "active" | "inactive" | "discontinued") => handleInputChange("status", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">
                    <Badge variant="default" className="bg-green-500">
                      Activo
                    </Badge>
                  </SelectItem>
                  <SelectItem value="inactive">
                    <Badge variant="secondary">Inactivo</Badge>
                  </SelectItem>
                  <SelectItem value="discontinued">
                    <Badge variant="destructive">Descontinuado</Badge>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Inventory Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Información de Inventario</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="quantity">Cantidad en Stock *</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                value={formData.quantity}
                onChange={(e) => handleInputChange("quantity", Number.parseInt(e.target.value) || 0)}
                placeholder="0"
                className={errors.quantity ? "border-red-500" : ""}
              />
              {errors.quantity && <p className="text-sm text-red-500 mt-1">{errors.quantity}</p>}
            </div>

            <div>
              <Label htmlFor="unitPrice">Precio Unitario (S/) *</Label>
              <Input
                id="unitPrice"
                type="number"
                min="0"
                step="0.01"
                value={formData.unitPrice}
                onChange={(e) => handleInputChange("unitPrice", Number.parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                className={errors.unitPrice ? "border-red-500" : ""}
              />
              {errors.unitPrice && <p className="text-sm text-red-500 mt-1">{errors.unitPrice}</p>}
            </div>

            <div>
              <Label htmlFor="supplier">Proveedor *</Label>
              <Input
                id="supplier"
                value={formData.supplier}
                onChange={(e) => handleInputChange("supplier", e.target.value)}
                placeholder="Nombre del proveedor"
                className={errors.supplier ? "border-red-500" : ""}
              />
              {errors.supplier && <p className="text-sm text-red-500 mt-1">{errors.supplier}</p>}
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-700">
                <strong>Valor Total:</strong> S/ {(formData.quantity * formData.unitPrice).toFixed(2)}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Assignment Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Información de Asignación</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="department">Departamento *</Label>
              <Select value={formData.department} onValueChange={(value) => handleInputChange("department", value)}>
                <SelectTrigger className={errors.department ? "border-red-500" : ""}>
                  <SelectValue placeholder="Seleccionar departamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Administración">Administración</SelectItem>
                  <SelectItem value="Recursos Humanos">Recursos Humanos</SelectItem>
                  <SelectItem value="Gerencia">Gerencia</SelectItem>
                  <SelectItem value="Ventas">Ventas</SelectItem>
                  <SelectItem value="Marketing">Marketing</SelectItem>
                  <SelectItem value="Operaciones">Operaciones</SelectItem>
                  <SelectItem value="Finanzas">Finanzas</SelectItem>
                  <SelectItem value="Tecnología">Tecnología</SelectItem>
                </SelectContent>
              </Select>
              {errors.department && <p className="text-sm text-red-500 mt-1">{errors.department}</p>}
            </div>

            <div>
              <Label htmlFor="assignedTo">Asignado a</Label>
              <Input
                id="assignedTo"
                value={formData.assignedTo}
                onChange={(e) => handleInputChange("assignedTo", e.target.value)}
                placeholder="Nombre del responsable"
              />
            </div>

            <div>
              <Label htmlFor="notes">Notas Adicionales</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleInputChange("notes", e.target.value)}
                placeholder="Observaciones, instrucciones especiales, etc."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end space-x-4">
        <Button type="button" variant="outline" onClick={() => window.location.reload()}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Limpiar Formulario
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
          {isSubmitting ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
          {isEditing ? "Actualizar Artículo" : "Registrar Artículo"}
        </Button>
      </div>

      {Object.keys(errors).length > 0 && (
        <Alert variant="destructive">
          <AlertDescription>
            Por favor, corrige los errores marcados en el formulario antes de continuar.
          </AlertDescription>
        </Alert>
      )}
    </form>
  )
}
