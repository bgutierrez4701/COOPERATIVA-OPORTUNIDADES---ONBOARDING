"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Search, Filter, Eye, Edit, Trash2, Download, Package, Calendar, User, Building } from "lucide-react"
import type { Item, ItemType } from "@/app/page"
import ItemRegistrationForm from "./item-registration-form"

interface ItemsListProps {
  items: Item[]
  onUpdate: (id: string, updatedItem: Partial<Item>) => void
  onDelete: (id: string) => void
  itemType: ItemType
}

export default function ItemsList({ items, onUpdate, onDelete, itemType }: ItemsListProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedItem, setSelectedItem] = useState<Item | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

  const filteredItems = items.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.department.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Activo</Badge>
      case "inactive":
        return <Badge variant="secondary">Inactivo</Badge>
      case "discontinued":
        return <Badge variant="destructive">Descontinuado</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleEdit = (item: Item) => {
    setSelectedItem(item)
    setIsEditDialogOpen(true)
  }

  const handleView = (item: Item) => {
    setSelectedItem(item)
    setIsViewDialogOpen(true)
  }

  const handleUpdate = (updatedData: Omit<Item, "id" | "dateAdded">) => {
    if (selectedItem) {
      onUpdate(selectedItem.id, updatedData)
      setIsEditDialogOpen(false)
      setSelectedItem(null)
    }
  }

  const handleDelete = (item: Item) => {
    if (confirm(`¿Estás seguro de que quieres eliminar "${item.name}"?`)) {
      onDelete(item.id)
    }
  }

  const totalValue = filteredItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Buscar por nombre, código, proveedor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filtros
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{filteredItems.length}</div>
              <div className="text-sm text-gray-600">Total Artículos</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {filteredItems.reduce((sum, item) => sum + item.quantity, 0)}
              </div>
              <div className="text-sm text-gray-600">Cantidad Total</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">S/ {totalValue.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Valor Total</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {filteredItems.filter((item) => item.status === "active").length}
              </div>
              <div className="text-sm text-gray-600">Activos</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Items Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista de Artículos</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredItems.length === 0 ? (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No se encontraron artículos</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Color</TableHead>
                    <TableHead>Talla</TableHead>
                    <TableHead>Cantidad</TableHead>
                    <TableHead>Precio Unit.</TableHead>
                    <TableHead>Estado</TableHead>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-mono text-sm">{item.code}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-gray-500">{item.supplier}</div>
                        </div>
                      </TableCell>
                      <TableCell>{item.color}</TableCell>
                      <TableCell>{item.size || "N/A"}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.quantity}</Badge>
                      </TableCell>
                      <TableCell>S/ {item.unitPrice.toFixed(2)}</TableCell>
                      <TableCell>{getStatusBadge(item.status)}</TableCell>
                      <TableCell>{item.department}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => handleView(item)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(item)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleDelete(item)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Artículo</DialogTitle>
          </DialogHeader>
          {selectedItem && <ItemRegistrationForm onSubmit={handleUpdate} initialData={selectedItem} isEditing={true} />}
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Detalles del Artículo</DialogTitle>
          </DialogHeader>
          {selectedItem && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-lg">{selectedItem.name}</h3>
                  <p className="text-gray-600">{selectedItem.description}</p>
                </div>
                <div className="text-right">{getStatusBadge(selectedItem.status)}</div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Código</Label>
                  <p className="font-mono">{selectedItem.code}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Color</Label>
                  <p>{selectedItem.color}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Talla</Label>
                  <p>{selectedItem.size || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Material</Label>
                  <p>{selectedItem.material}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Cantidad</Label>
                  <p className="font-semibold">{selectedItem.quantity}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Precio Unitario</Label>
                  <p className="font-semibold">S/ {selectedItem.unitPrice.toFixed(2)}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-gray-500" />
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Departamento</Label>
                      <p>{selectedItem.department}</p>
                    </div>
                  </div>
                  {selectedItem.assignedTo && (
                    <div className="flex items-center space-x-2">
                      <User className="h-4 w-4 text-gray-500" />
                      <div>
                        <Label className="text-sm font-medium text-gray-500">Asignado a</Label>
                        <p>{selectedItem.assignedTo}</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Fecha de Registro</Label>
                      <p>{new Date(selectedItem.dateAdded).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-500">Proveedor</Label>
                    <p>{selectedItem.supplier}</p>
                  </div>
                </div>
              </div>

              {selectedItem.notes && (
                <div className="border-t pt-4">
                  <Label className="text-sm font-medium text-gray-500">Notas</Label>
                  <p className="mt-1 text-gray-700">{selectedItem.notes}</p>
                </div>
              )}

              <div className="bg-blue-50 p-4 rounded-lg">
                <Label className="text-sm font-medium text-blue-700">Valor Total del Stock</Label>
                <p className="text-xl font-bold text-blue-800">
                  S/ {(selectedItem.quantity * selectedItem.unitPrice).toFixed(2)}
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={className}>{children}</label>
}
