"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Info, Heart, Users, GraduationCap, Briefcase } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

export default function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { signIn, isSupabaseConfigured } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    const { error } = await signIn(email, password)

    if (error) {
      setError("Credenciales incorrectas. Por favor, verifica tu email y contraseña.")
    }

    setLoading(false)
  }

  const fillDemoCredentials = (type: "admin" | "user") => {
    if (type === "admin") {
      setEmail("admin@coopoportunidades.com")
      setPassword("admin123")
    } else {
      setEmail("asesor@coopoportunidades.com")
      setPassword("asesor123")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-warm flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 bg-primary-500 rounded-full"></div>
        <div className="absolute top-32 right-20 w-16 h-16 bg-secondary-500 rounded-full"></div>
        <div className="absolute bottom-20 left-32 w-24 h-24 bg-accent-500 rounded-full"></div>
        <div className="absolute bottom-40 right-10 w-12 h-12 bg-primary-300 rounded-full"></div>
      </div>

      {/* Hero Image Section */}
      <div className="hidden lg:flex lg:w-1/2 relative">
        <div className="relative w-full h-screen">
          <img
            src="/images/peruvian-women-entrepreneurs.jpg"
            alt="Asesores de crédito trabajando con emprendedoras peruanas"
            className="w-full h-full object-cover rounded-r-3xl shadow-2xl"
          />
          <div className="absolute inset-0 bg-gradient-brand opacity-80 rounded-r-3xl"></div>
          <div className="absolute inset-0 flex flex-col justify-center items-center text-white p-8">
            <div className="text-center animate-fade-in">
              <div className="mb-4">
                <Briefcase className="h-16 w-16 mx-auto mb-4 text-white/90" />
              </div>
              <h1 className="text-5xl font-bold mb-2">Onboarding para</h1>
              <h1 className="text-5xl font-bold mb-4 text-secondary-200">Asesores de Crédito</h1>
              <p className="text-xl mb-6 opacity-90">Capacitación integral para nuevos colaboradores</p>
              <div className="flex items-center justify-center space-x-6 text-sm">
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Equipo de Asesores</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Heart className="h-5 w-5" />
                  <span>Servicio a 5,000+ Socias</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Login Form Section */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <Card className="w-full max-w-md shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="flex space-x-2">
                  <div className="w-4 h-16 bg-primary-500 rounded-full shadow-lg"></div>
                  <div className="w-4 h-16 bg-secondary-500 rounded-full shadow-lg"></div>
                  <div className="w-4 h-16 bg-primary-300 rounded-full shadow-lg"></div>
                </div>
                <div className="absolute -inset-2 bg-gradient-brand opacity-20 rounded-full blur-xl"></div>
              </div>
            </div>
            <CardTitle className="text-3xl font-bold text-primary-500">Oportunidades</CardTitle>
            <p className="text-sm text-secondary-600 uppercase tracking-wide font-semibold">CONTIGO ES POSIBLE</p>
            <div className="mt-3 p-3 bg-primary-50 rounded-lg border border-primary-200">
              <div className="flex items-center justify-center space-x-2 text-primary-700">
                <GraduationCap className="h-5 w-5" />
                <span className="font-semibold">Onboarding de Asesores</span>
              </div>
              <p className="text-xs text-primary-600 mt-1">Portal de Capacitación para Nuevos Colaboradores</p>
            </div>
          </CardHeader>
          <CardContent className="pt-2">
            {!isSupabaseConfigured && (
              <Alert className="mb-6 border-primary-200 bg-primary-50">
                <Info className="h-4 w-4 text-primary-600" />
                <AlertDescription className="text-primary-800">
                  <strong>Modo Demo:</strong> Supabase no está configurado. Usa las credenciales de prueba:
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-medium">Administrador:</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fillDemoCredentials("admin")}
                        className="text-xs h-7 border-primary-300 text-primary-700 hover:bg-primary-50"
                      >
                        Usar Admin
                      </Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-medium">Nuevo Asesor:</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fillDemoCredentials("user")}
                        className="text-xs h-7 border-secondary-300 text-secondary-700 hover:bg-secondary-50"
                      >
                        Usar Asesor
                      </Button>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 font-medium">
                  Correo Corporativo
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu.nombre@coopoportunidades.com"
                  required
                  className="border-primary-200 focus:border-primary-400 focus:ring-primary-400/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700 font-medium">
                  Contraseña
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="border-primary-200 focus:border-primary-400 focus:ring-primary-400/20 pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </Button>
                </div>
              </div>

              {error && (
                <Alert variant="destructive" className="border-red-200 bg-red-50">
                  <AlertDescription className="text-red-800">{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full bg-gradient-brand hover:opacity-90 text-white font-semibold py-3 rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
                disabled={loading}
              >
                {loading ? "Iniciando Onboarding..." : "Comenzar Capacitación"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">¿Nuevo en el equipo?</p>
              <p className="text-sm font-medium text-primary-600">Contacta a Recursos Humanos para acceso</p>
            </div>

            {/* Decorative Elements */}
            <div className="mt-6 flex justify-center space-x-4 opacity-60">
              <div className="w-2 h-2 bg-primary-400 rounded-full"></div>
              <div className="w-2 h-2 bg-secondary-400 rounded-full"></div>
              <div className="w-2 h-2 bg-primary-300 rounded-full"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
