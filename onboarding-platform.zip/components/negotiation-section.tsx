"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, MessageCircle, Target, Users, CheckCircle, AlertTriangle, Lightbulb } from "lucide-react"

interface NegotiationSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function NegotiationSection({ onComplete, onNext }: NegotiationSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const principles = [
    {
      title: "Preparación",
      description: "Investiga y planifica antes de negociar",
      icon: Target,
      color: "text-primary-600",
      tips: ["Define tus objetivos claramente", "Conoce a la otra parte", "Prepara alternativas", "Establece límites"],
    },
    {
      title: "Comunicación Efectiva",
      description: "Escucha activamente y comunica con claridad",
      icon: MessageCircle,
      color: "text-secondary-600",
      tips: ["Practica la escucha activa", "Haz preguntas abiertas", "Usa lenguaje positivo", "Confirma entendimiento"],
    },
    {
      title: "Búsqueda de Soluciones",
      description: "Enfócate en intereses mutuos, no en posiciones",
      icon: Lightbulb,
      color: "text-primary-600",
      tips: [
        "Identifica intereses comunes",
        "Genera múltiples opciones",
        "Piensa creativamente",
        "Busca beneficio mutuo",
      ],
    },
    {
      title: "Construcción de Relaciones",
      description: "Mantén relaciones positivas a largo plazo",
      icon: Users,
      color: "text-secondary-600",
      tips: ["Respeta a la otra parte", "Mantén la profesionalidad", "Construye confianza", "Piensa a largo plazo"],
    },
  ]

  const strategies = [
    {
      name: "Ganar-Ganar",
      description: "Buscar beneficios mutuos para todas las partes",
      when: "Relaciones a largo plazo, intereses alineados",
      example: "Negociar plazos de pago que beneficien tanto al prestamista como al prestatario",
    },
    {
      name: "Colaborativa",
      description: "Trabajar juntos para encontrar la mejor solución",
      when: "Problemas complejos, múltiples opciones disponibles",
      example: "Desarrollar un plan de pagos personalizado para un socio con dificultades",
    },
    {
      name: "Competitiva",
      description: "Defender firmemente tus intereses principales",
      when: "Recursos limitados, principios no negociables",
      example: "Mantener estándares de calidad mínimos en productos o servicios",
    },
    {
      name: "Acomodativa",
      description: "Ceder en puntos menos importantes para ganar en otros",
      when: "Relación más importante que el resultado específico",
      example: "Ser flexible en fechas para asegurar un acuerdo importante",
    },
  ]

  const phases = [
    {
      phase: "Preparación",
      description: "Investigación y planificación previa",
      activities: ["Definir objetivos", "Investigar a la contraparte", "Preparar argumentos", "Establecer límites"],
    },
    {
      phase: "Apertura",
      description: "Establecimiento del tono y las reglas",
      activities: ["Crear ambiente positivo", "Establecer agenda", "Definir reglas básicas", "Construir rapport"],
    },
    {
      phase: "Exploración",
      description: "Intercambio de información e intereses",
      activities: ["Escuchar activamente", "Hacer preguntas", "Identificar intereses", "Explorar opciones"],
    },
    {
      phase: "Negociación",
      description: "Intercambio de propuestas y concesiones",
      activities: ["Presentar propuestas", "Hacer concesiones", "Buscar compromisos", "Evaluar opciones"],
    },
    {
      phase: "Cierre",
      description: "Finalización y documentación del acuerdo",
      activities: ["Resumir acuerdos", "Documentar términos", "Establecer seguimiento", "Celebrar éxito"],
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Negociación Efectiva</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Desarrolla habilidades de negociación para resolver conflictos, cerrar acuerdos y mantener relaciones
          positivas en tu grupo de crédito y negocio.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-xl text-center text-primary-900">La Negociación: Un Arte y una Ciencia</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-primary-800">
            La negociación efectiva no se trata de ganar o perder, sino de encontrar soluciones que beneficien a todas
            las partes involucradas, especialmente importante en los créditos grupales.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {principles.map((principle, index) => {
          const Icon = principle.icon
          return (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Icon className={`h-6 w-6 ${principle.color}`} />
                  <div>
                    <CardTitle className="text-lg">{principle.title}</CardTitle>
                    <p className="text-sm text-gray-600">{principle.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {principle.tips.map((tip, tipIndex) => (
                    <li key={tipIndex} className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                      <span className="text-sm text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Estrategias de Negociación</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {strategies.map((strategy, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-lg">{strategy.name}</h4>
                  <Badge variant="outline">Estrategia</Badge>
                </div>
                <p className="text-gray-600 mb-3">{strategy.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-semibold text-sm text-primary-700 mb-1">Cuándo usar:</h5>
                    <p className="text-sm text-gray-600">{strategy.when}</p>
                  </div>
                  <div>
                    <h5 className="font-semibold text-sm text-secondary-700 mb-1">Ejemplo:</h5>
                    <p className="text-sm text-gray-600">{strategy.example}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Fases de la Negociación</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {phases.map((phase, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="bg-primary-100 rounded-full w-10 h-10 flex items-center justify-center">
                  <span className="text-primary-600 font-bold">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-lg mb-1">{phase.phase}</h4>
                  <p className="text-gray-600 mb-2">{phase.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {phase.activities.map((activity, actIndex) => (
                      <Badge key={actIndex} variant="secondary" className="text-xs">
                        {activity}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-green-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span>Qué SÍ hacer</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full mt-2"></span>
                <span className="text-sm">Mantener la calma y profesionalismo</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full mt-2"></span>
                <span className="text-sm">Buscar soluciones creativas</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full mt-2"></span>
                <span className="text-sm">Documentar acuerdos por escrito</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-green-500 rounded-full mt-2"></span>
                <span className="text-sm">Respetar los tiempos de reflexión</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <span>Qué NO hacer</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full mt-2"></span>
                <span className="text-sm">Tomar decisiones bajo presión emocional</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full mt-2"></span>
                <span className="text-sm">Hacer amenazas o ultimátums</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full mt-2"></span>
                <span className="text-sm">Revelar toda tu información de una vez</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-red-500 rounded-full mt-2"></span>
                <span className="text-sm">Aceptar el primer "no" como definitivo</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">🤝 Aplicación en Créditos Grupales</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-blue-800">Resolución de Conflictos</h4>
            <p className="text-sm text-blue-700">Mediar disputas entre miembros del grupo</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Acuerdos de Pago</h4>
            <p className="text-sm text-blue-700">Negociar plazos y condiciones flexibles</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Distribución de Responsabilidades</h4>
            <p className="text-sm text-blue-700">Asignar roles y tareas equitativamente</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Decisiones Grupales</h4>
            <p className="text-sm text-blue-700">Llegar a consensos en decisiones importantes</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Aprender sobre Trabajo en Equipo
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
