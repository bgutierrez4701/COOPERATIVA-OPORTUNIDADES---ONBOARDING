"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Calendar, Users, TrendingUp, Award, Building, MapPin } from "lucide-react"

interface OurHistorySectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function OurHistorySection({ onComplete, onNext }: OurHistorySectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const milestones = [
    {
      year: "2010",
      title: "Fundación de la Cooperativa",
      description: "Inicio de operaciones con 50 socios fundadores y un capital inicial de $100,000",
      icon: Building,
      color: "bg-primary-100 text-primary-600",
    },
    {
      year: "2012",
      title: "Primer Programa de Créditos Grupales",
      description: "Lanzamiento de nuestra metodología de créditos solidarios, beneficiando a 200 familias",
      icon: Users,
      color: "bg-secondary-100 text-secondary-600",
    },
    {
      year: "2015",
      title: "Expansión Regional",
      description: "Apertura de 3 sucursales adicionales, alcanzando 1,500 socios activos",
      icon: MapPin,
      color: "bg-primary-100 text-primary-600",
    },
    {
      year: "2018",
      title: "Reconocimiento Nacional",
      description: "Premio a la Mejor Cooperativa de Microfinanzas del país",
      icon: Award,
      color: "bg-secondary-100 text-secondary-600",
    },
    {
      year: "2020",
      title: "Transformación Digital",
      description: "Implementación de servicios digitales y banca móvil para nuestros socios",
      icon: TrendingUp,
      color: "bg-primary-100 text-primary-600",
    },
    {
      year: "2024",
      title: "Presente",
      description: "Más de 5,000 socios activos y $10 millones en cartera de créditos",
      icon: Calendar,
      color: "bg-secondary-100 text-secondary-600",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestra Historia</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Más de una década transformando vidas y construyendo oportunidades en nuestras comunidades.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary-600 mb-2">14+</div>
            <div className="text-gray-600">Años de experiencia</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-secondary-600 mb-2">5,000+</div>
            <div className="text-gray-600">Socios activos</div>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary-600 mb-2">$10M+</div>
            <div className="text-gray-600">En créditos otorgados</div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <h3 className="text-2xl font-semibold text-center mb-6">Nuestro Recorrido</h3>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary-300 to-secondary-300"></div>

          <div className="space-y-8">
            {milestones.map((milestone, index) => {
              const Icon = milestone.icon
              return (
                <div key={index} className="relative flex items-start space-x-6">
                  {/* Timeline dot */}
                  <div
                    className={`relative z-10 flex items-center justify-center w-16 h-16 rounded-full ${milestone.color}`}
                  >
                    <Icon className="h-8 w-8" />
                  </div>

                  {/* Content */}
                  <Card className="flex-1">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl">{milestone.title}</CardTitle>
                        <Badge variant="outline" className="text-lg px-3 py-1">
                          {milestone.year}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600">{milestone.description}</p>
                    </CardContent>
                  </Card>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-xl text-center">Nuestro Impacto en Números</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-primary-600">15,000+</div>
              <div className="text-sm text-gray-600">Familias beneficiadas</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-secondary-600">2,500+</div>
              <div className="text-sm text-gray-600">Microempresas creadas</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary-600">95%</div>
              <div className="text-sm text-gray-600">Tasa de recuperación</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-secondary-600">8</div>
              <div className="text-sm text-gray-600">Sucursales activas</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">💡 ¿Sabías que...?</h3>
        <ul className="space-y-2 text-blue-800">
          <li>• El 85% de nuestros socios son mujeres emprendedoras</li>
          <li>• Hemos contribuido a la creación de más de 2,500 microempresas</li>
          <li>• Nuestra metodología de créditos grupales tiene una tasa de éxito del 95%</li>
          <li>• Somos la primera cooperativa en implementar educación financiera digital</li>
        </ul>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Conocer los Créditos Grupales
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
