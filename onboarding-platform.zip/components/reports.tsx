"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, FileText, BarChart3, PieChart, TrendingUp, Calendar, Filter } from "lucide-react"
import type { Item } from "@/app/page"

interface ReportsProps {
  items: Item[]
}

export default function Reports({ items }: ReportsProps) {
  const generateInventoryReport = () => {
    console.log("Generating inventory report...")
  }

  const generateValueReport = () => {
    console.log("Generating value report...")
  }

  const generateDepartmentReport = () => {
    console.log("Generating department report...")
  }

  const totalValue = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)
  const totalQuantity = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Reportes y Análisis</h2>
          <p className="text-gray-600">Genera reportes detallados del inventario</p>
        </div>
        <div className="flex items-center space-x-2">
          <Select defaultValue="monthly">
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Semanal</SelectItem>
              <SelectItem value="monthly">Mensual</SelectItem>
              <SelectItem value="quarterly">Trimestral</SelectItem>
              <SelectItem value="yearly">Anual</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filtros
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{items.length}</div>
              <div className="text-sm text-gray-600">Total Artículos</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{totalQuantity}</div>
              <div className="text-sm text-gray-600">Unidades Totales</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">S/ {totalValue.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Valor Total</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {items.filter((item) => item.status === "active").length}
              </div>
              <div className="text-sm text-gray-600">Artículos Activos</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-blue-600" />
              <span>Reporte de Inventario</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Listado completo de todos los artículos con detalles de stock, precios y ubicaciones.
            </p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Incluye: Stock actual</Badge>
              <Badge variant="outline">Incluye: Valores</Badge>
              <Badge variant="outline">Incluye: Proveedores</Badge>
            </div>
            <Button onClick={generateInventoryReport} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Generar Reporte
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-green-600" />
              <span>Análisis de Valor</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Análisis detallado del valor del inventario por categorías y departamentos.
            </p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Por categoría</Badge>
              <Badge variant="outline">Por departamento</Badge>
              <Badge variant="outline">Tendencias</Badge>
            </div>
            <Button onClick={generateValueReport} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Generar Análisis
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <PieChart className="h-5 w-5 text-purple-600" />
              <span>Distribución por Departamento</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Distribución de artículos y valores asignados a cada departamento.</p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Cantidad por depto</Badge>
              <Badge variant="outline">Valor por depto</Badge>
              <Badge variant="outline">Asignaciones</Badge>
            </div>
            <Button onClick={generateDepartmentReport} className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Generar Reporte
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-orange-600" />
              <span>Reporte de Movimientos</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Historial de entradas, salidas y movimientos de inventario.</p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Entradas</Badge>
              <Badge variant="outline">Salidas</Badge>
              <Badge variant="outline">Transferencias</Badge>
            </div>
            <Button className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Generar Reporte
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-red-600" />
              <span>Reporte Mensual</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Resumen mensual con estadísticas y métricas clave del inventario.</p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Resumen ejecutivo</Badge>
              <Badge variant="outline">KPIs</Badge>
              <Badge variant="outline">Gráficos</Badge>
            </div>
            <Button className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Generar Reporte
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-indigo-600" />
              <span>Reporte Personalizado</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">Crea reportes personalizados con los campos y filtros que necesites.</p>
            <div className="space-y-2 mb-4">
              <Badge variant="outline">Campos personalizados</Badge>
              <Badge variant="outline">Filtros avanzados</Badge>
              <Badge variant="outline">Formato flexible</Badge>
            </div>
            <Button className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Configurar Reporte
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Reportes Recientes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <FileText className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Inventario General - Enero 2024</p>
                  <p className="text-sm text-gray-600">Generado el 15/01/2024</p>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Descargar
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <BarChart3 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Análisis de Valor por Departamento</p>
                  <p className="text-sm text-gray-600">Generado el 10/01/2024</p>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Descargar
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="font-medium">Movimientos de Stock - Diciembre 2023</p>
                  <p className="text-sm text-gray-600">Generado el 05/01/2024</p>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Descargar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
