"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ExternalLink,
  BookOpen,
  Users,
  Monitor,
  Wifi,
  Coffee,
  Car,
  Heart,
  GraduationCap,
  Phone,
  Mail,
  MessageCircle,
} from "lucide-react"

interface ResourcesSectionProps {
  onComplete: () => void
}

export default function ResourcesSection({ onComplete }: ResourcesSectionProps) {
  const handleComplete = () => {
    onComplete()
  }

  const tools = [
    {
      name: "Portal del Socio",
      description: "Acceso a tu cuenta y servicios en línea",
      category: "Servicios",
      icon: Monitor,
      link: "#",
    },
    {
      name: "Banca Móvil",
      description: "Aplicación móvil para transacciones",
      category: "Servicios",
      icon: MessageCircle,
      link: "#",
    },
    {
      name: "Sistema de Créditos",
      description: "Solicitud y seguimiento de préstamos",
      category: "Financiero",
      icon: BookOpen,
      link: "#",
    },
    {
      name: "Centro de Capacitación",
      description: "Cursos y talleres para socios",
      category: "Educación",
      icon: GraduationCap,
      link: "#",
    },
  ]

  const benefits = [
    {
      title: "Servicios Financieros Preferenciales",
      description: "Tasas especiales y condiciones favorables",
      icon: Heart,
      details: ["Tasas de interés preferenciales", "Comisiones reducidas", "Asesoría financiera gratuita"],
    },
    {
      title: "Programas de Educación",
      description: "Capacitación continua en temas financieros",
      icon: GraduationCap,
      details: ["Talleres de educación financiera", "Cursos de emprendimiento", "Seminarios cooperativos"],
    },
    {
      title: "Beneficios Sociales",
      description: "Programas de bienestar para socios y familias",
      icon: Users,
      details: ["Actividades recreativas", "Programas de salud", "Eventos familiares"],
    },
    {
      title: "Participación Democrática",
      description: "Voz y voto en las decisiones cooperativas",
      icon: Wifi,
      details: ["Derecho a voto en asambleas", "Participación en comités", "Propuestas de mejora"],
    },
  ]

  const contacts = [
    {
      name: "Atención a Socios",
      role: "Información general y servicios",
      phone: "+1 (555) 123-4567",
      email: "atencion@coopoportunidades.com",
      hours: "Lun-Vie 8:00-17:00",
    },
    {
      name: "Asesoría Financiera",
      role: "Consultas sobre créditos y ahorros",
      phone: "+1 (555) 123-4568",
      email: "asesoria@coopoportunidades.com",
      hours: "Lun-Vie 8:00-16:00",
    },
    {
      name: "Tu Asesor Personal",
      role: "Acompañamiento personalizado",
      phone: "+1 (555) 123-4569",
      email: "asesor@coopoportunidades.com",
      hours: "Lun-Vie 8:00-17:00",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Recursos y Herramientas</h2>
        <p className="text-lg text-gray-600">Todo lo que necesitas para ser productivo desde el primer día</p>
      </div>

      <Tabs defaultValue="tools" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tools">Herramientas</TabsTrigger>
          <TabsTrigger value="benefits">Beneficios</TabsTrigger>
          <TabsTrigger value="contacts">Contactos</TabsTrigger>
          <TabsTrigger value="facilities">Instalaciones</TabsTrigger>
        </TabsList>

        <TabsContent value="tools" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tools.map((tool, index) => {
              const Icon = tool.icon
              return (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon className="h-6 w-6 text-primary-600" />
                        <div>
                          <CardTitle className="text-lg">{tool.name}</CardTitle>
                          <CardDescription>{tool.description}</CardDescription>
                        </div>
                      </div>
                      <Badge variant="outline">{tool.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Acceder
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="benefits" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon
              return (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <Icon className="h-6 w-6 text-secondary-600" />
                      <div>
                        <CardTitle className="text-lg">{benefit.title}</CardTitle>
                        <CardDescription>{benefit.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-1">
                      {benefit.details.map((detail, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center">
                          <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-4">
          <div className="space-y-4">
            {contacts.map((contact, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{contact.name}</h3>
                      <p className="text-gray-600">{contact.role}</p>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Phone className="h-4 w-4" />
                          <span>{contact.phone}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Mail className="h-4 w-4" />
                          <span>{contact.email}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">{contact.hours}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="facilities" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Coffee className="h-6 w-6 text-secondary-600" />
                  <div>
                    <CardTitle>Cafetería</CardTitle>
                    <CardDescription>Piso 1 - Área común</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">Café gratuito, snacks y área de descanso. Abierto 24/7.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Users className="h-6 w-6 text-primary-600" />
                  <div>
                    <CardTitle>Salas de Reuniones</CardTitle>
                    <CardDescription>Todos los pisos</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Reserva a través del calendario de Google. Equipadas con videoconferencia.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Monitor className="h-6 w-6 text-primary-600" />
                  <div>
                    <CardTitle>Área de Trabajo</CardTitle>
                    <CardDescription>Piso 3 - Tu departamento</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Escritorios asignados con monitores duales y estaciones de trabajo ergonómicas.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Car className="h-6 w-6 text-secondary-600" />
                  <div>
                    <CardTitle>Estacionamiento</CardTitle>
                    <CardDescription>Sótano B1</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Acceso con tarjeta de empleado. Espacios para autos eléctricos disponibles.
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-primary-900 mb-2">🎉 ¡Felicitaciones!</h3>
          <p className="text-primary-800 mb-4">
            Has completado exitosamente tu proceso de incorporación. ¡Bienvenido oficialmente como socio de COOPERATIVA
            OPORTUNIDADES!
          </p>
          <Button onClick={handleComplete} size="lg" className="bg-primary-600 hover:bg-primary-700">
            Finalizar Incorporación
          </Button>
        </div>
      </div>
    </div>
  )
}
