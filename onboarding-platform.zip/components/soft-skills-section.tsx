"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, Brain, Heart, MessageCircle, Users, Target, Lightbulb } from "lucide-react"

interface SoftSkillsSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function SoftSkillsSection({ onComplete, onNext }: SoftSkillsSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const skills = [
    {
      title: "Comunicación Efectiva",
      description: "Expresar ideas claramente y escuchar activamente",
      icon: MessageCircle,
      importance: 95,
      tips: [
        "Practica la escucha activa",
        "Sé claro y conciso en tus mensajes",
        "Adapta tu comunicación al público",
        "Usa lenguaje corporal positivo",
      ],
    },
    {
      title: "Inteligencia Emocional",
      description: "Gestionar emociones propias y entender las de otros",
      icon: Heart,
      importance: 90,
      tips: [
        "Reconoce tus emociones",
        "Practica la empatía",
        "Controla tus reacciones",
        "Desarrolla la autoconciencia",
      ],
    },
    {
      title: "Liderazgo",
      description: "Inspirar y guiar a otros hacia objetivos comunes",
      icon: Users,
      importance: 85,
      tips: ["Lidera con el ejemplo", "Delega responsabilidades", "Motiva a tu equipo", "Toma decisiones informadas"],
    },
    {
      title: "Pensamiento Crítico",
      description: "Analizar información y tomar decisiones fundamentadas",
      icon: Brain,
      importance: 88,
      tips: [
        "Cuestiona suposiciones",
        "Analiza múltiples perspectivas",
        "Busca evidencia sólida",
        "Evalúa consecuencias",
      ],
    },
    {
      title: "Adaptabilidad",
      description: "Ajustarse a cambios y nuevas situaciones",
      icon: Target,
      importance: 82,
      tips: [
        "Mantén una mente abierta",
        "Aprende continuamente",
        "Acepta los cambios",
        "Busca oportunidades en los desafíos",
      ],
    },
    {
      title: "Creatividad",
      description: "Generar ideas innovadoras y soluciones originales",
      icon: Lightbulb,
      importance: 78,
      tips: [
        "Piensa fuera de la caja",
        "Experimenta con nuevas ideas",
        "Conecta conceptos diferentes",
        "No temas al fracaso",
      ],
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Refuerza tus Habilidades Blandas</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Las habilidades blandas son fundamentales para el éxito en los créditos grupales y en tu desarrollo
          profesional. Fortalece estas competencias clave.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-xl text-center text-primary-900">
            ¿Por qué son importantes las Habilidades Blandas?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-primary-600 mb-2">85%</div>
              <div className="text-sm text-gray-600">Del éxito profesional depende de habilidades blandas</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-secondary-600 mb-2">70%</div>
              <div className="text-sm text-gray-600">De los empleadores las consideran más importantes</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary-600 mb-2">90%</div>
              <div className="text-sm text-gray-600">De los grupos exitosos tienen líderes con estas habilidades</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {skills.map((skill, index) => {
          const Icon = skill.icon
          return (
            <Card key={index} className="h-full">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="bg-primary-100 rounded-full p-2">
                    <Icon className="h-6 w-6 text-primary-600" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">{skill.title}</CardTitle>
                    <p className="text-sm text-gray-600">{skill.description}</p>
                  </div>
                </div>
                <div className="mt-3">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Importancia</span>
                    <span>{skill.importance}%</span>
                  </div>
                  <Progress value={skill.importance} className="h-2" />
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-semibold mb-3 text-secondary-700">Consejos para desarrollarla:</h4>
                <ul className="space-y-2">
                  {skill.tips.map((tip, tipIndex) => (
                    <li key={tipIndex} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 bg-secondary-500 rounded-full mt-2"></span>
                      <span className="text-sm text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Plan de Desarrollo Personal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="bg-primary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-primary-600 font-bold">1</span>
              </div>
              <h4 className="font-semibold mb-2">Autoevaluación</h4>
              <p className="text-sm text-gray-600">Identifica tus fortalezas y áreas de mejora</p>
            </div>
            <div className="text-center">
              <div className="bg-secondary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-secondary-600 font-bold">2</span>
              </div>
              <h4 className="font-semibold mb-2">Establece Metas</h4>
              <p className="text-sm text-gray-600">Define objetivos específicos y medibles</p>
            </div>
            <div className="text-center">
              <div className="bg-primary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-primary-600 font-bold">3</span>
              </div>
              <h4 className="font-semibold mb-2">Practica</h4>
              <p className="text-sm text-gray-600">Aplica las habilidades en situaciones reales</p>
            </div>
            <div className="text-center">
              <div className="bg-secondary-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                <span className="text-secondary-600 font-bold">4</span>
              </div>
              <h4 className="font-semibold mb-2">Evalúa</h4>
              <p className="text-sm text-gray-600">Mide tu progreso y ajusta tu plan</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">💡 Aplicación en Créditos Grupales</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-blue-800">Comunicación</h4>
            <p className="text-sm text-blue-700">Facilita las reuniones grupales y resolución de conflictos</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Liderazgo</h4>
            <p className="text-sm text-blue-700">Ayuda a coordinar actividades y motivar al grupo</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Inteligencia Emocional</h4>
            <p className="text-sm text-blue-700">Mejora las relaciones interpersonales en el grupo</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Adaptabilidad</h4>
            <p className="text-sm text-blue-700">Permite ajustarse a cambios en el mercado o el grupo</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Aprender sobre Negociación
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
