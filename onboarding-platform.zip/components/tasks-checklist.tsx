"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowRight, CheckCircle, Clock, Calendar, Users, Laptop, Key, Coffee } from "lucide-react"

interface TasksChecklistProps {
  onComplete: () => void
  onNext: () => void
}

export default function TasksChecklist({ onComplete, onNext }: TasksChecklistProps) {
  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "Configurar acceso al portal del socio",
      description: "Activa tu cuenta en línea para servicios cooperativos",
      category: "Tecnología",
      priority: "Alta",
      completed: false,
      icon: Laptop,
      estimatedTime: "15 min",
    },
    {
      id: 2,
      title: "Reunión con tu asesor cooperativo",
      description: "Primera reunión con tu asesor personal asignado",
      category: "Reuniones",
      priority: "Alta",
      completed: false,
      icon: Users,
      estimatedTime: "60 min",
    },
    {
      id: 3,
      title: "Tour por las instalaciones",
      description: "Conoce nuestras oficinas y servicios disponibles",
      category: "Orientación",
      priority: "Media",
      completed: false,
      icon: Coffee,
      estimatedTime: "30 min",
    },
    {
      id: 4,
      title: "Apertura de cuenta de ahorros",
      description: "Abre tu primera cuenta como socio de la cooperativa",
      category: "Servicios",
      priority: "Alta",
      completed: false,
      icon: Key,
      estimatedTime: "45 min",
    },
    {
      id: 5,
      title: "Capacitación en principios cooperativos",
      description: "Aprende sobre el movimiento cooperativo y nuestros valores",
      category: "Capacitación",
      priority: "Alta",
      completed: false,
      icon: CheckCircle,
      estimatedTime: "90 min",
    },
    {
      id: 6,
      title: "Conocer a otros socios",
      description: "Participa en actividades sociales con la comunidad",
      category: "Social",
      priority: "Media",
      completed: false,
      icon: Users,
      estimatedTime: "120 min",
    },
    {
      id: 7,
      title: "Planificar tus objetivos financieros",
      description: "Sesión de asesoría para definir tus metas como socio",
      category: "Planificación",
      priority: "Alta",
      completed: false,
      icon: Calendar,
      estimatedTime: "60 min",
    },
    {
      id: 8,
      title: "Configurar servicios adicionales",
      description: "Activa servicios como banca móvil y notificaciones",
      category: "Servicios",
      priority: "Baja",
      completed: false,
      icon: Laptop,
      estimatedTime: "20 min",
    },
  ])

  const toggleTask = (taskId: number) => {
    setTasks((tasks) => tasks.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
  }

  const completedTasks = tasks.filter((task) => task.completed).length
  const progress = (completedTasks / tasks.length) * 100
  const highPriorityTasks = tasks.filter((task) => task.priority === "Alta")
  const completedHighPriority = highPriorityTasks.filter((task) => task.completed).length

  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Alta":
        return "destructive"
      case "Media":
        return "default"
      case "Baja":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Tecnología":
        return "bg-blue-100 text-blue-800"
      case "Reuniones":
        return "bg-green-100 text-green-800"
      case "Orientación":
        return "bg-purple-100 text-purple-800"
      case "Capacitación":
        return "bg-orange-100 text-orange-800"
      case "Social":
        return "bg-pink-100 text-pink-800"
      case "Planificación":
        return "bg-indigo-100 text-indigo-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Actividades de Incorporación - Primera Semana</h2>
        <p className="text-lg text-gray-600">
          Completa estas actividades para integrarte exitosamente como socio de la cooperativa
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-600">{completedTasks}</div>
              <div className="text-sm text-gray-600">Tareas Completadas</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-secondary-600">{completedHighPriority}</div>
              <div className="text-sm text-gray-600">Alta Prioridad Completadas</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-600">{Math.round(progress)}%</div>
              <div className="text-sm text-gray-600">Progreso Total</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Progreso General</span>
            <Badge variant="outline">
              {completedTasks} de {tasks.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="h-3" />
        </CardContent>
      </Card>

      <div className="space-y-4">
        {tasks.map((task) => {
          const Icon = task.icon
          return (
            <Card
              key={task.id}
              className={`transition-all ${task.completed ? "border-green-200 bg-green-50" : "border-gray-200"}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <Checkbox
                    id={`task-${task.id}`}
                    checked={task.completed}
                    onCheckedChange={() => toggleTask(task.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon className={`h-5 w-5 ${task.completed ? "text-green-600" : "text-gray-400"}`} />
                        <div>
                          <h3
                            className={`font-medium ${task.completed ? "line-through text-gray-500" : "text-gray-900"}`}
                          >
                            {task.title}
                          </h3>
                          <p
                            className={`text-sm mt-1 ${
                              task.completed ? "line-through text-gray-400" : "text-gray-600"
                            }`}
                          >
                            {task.description}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={getPriorityColor(task.priority)}>{task.priority}</Badge>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(task.category)}`}
                        >
                          {task.category}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center mt-2 space-x-4">
                      <div className="flex items-center space-x-1 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>{task.estimatedTime}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-semibold text-primary-900 mb-2">💡 Consejos para tu primera semana como socio:</h3>
        <ul className="space-y-1 text-sm text-primary-800">
          <li>• Pregunta sobre todos los servicios disponibles para socios</li>
          <li>• Participa activamente en las actividades cooperativas</li>
          <li>• Conoce a otros socios y comparte experiencias</li>
          <li>• Mantén una mentalidad colaborativa y solidaria</li>
        </ul>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Continuar a Recursos
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
