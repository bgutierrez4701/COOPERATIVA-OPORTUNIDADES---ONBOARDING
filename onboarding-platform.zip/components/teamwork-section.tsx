"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Target, MessageCircle, Award, Puzzle, Heart } from "lucide-react"

interface TeamworkSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function TeamworkSection({ onComplete, onNext }: TeamworkSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  const principles = [
    {
      title: "Comunicación Abierta",
      description: "Fomentar el diálogo honesto y transparente",
      icon: MessageCircle,
      color: "text-primary-600",
      benefits: [
        "Evita malentendidos",
        "Construye confianza",
        "Facilita la resolución de problemas",
        "Mejora la toma de decisiones",
      ],
    },
    {
      title: "Objetivos Compartidos",
      description: "Alinear metas individuales con objetivos grupales",
      icon: Target,
      color: "text-secondary-600",
      benefits: ["Unifica esfuerzos", "Aumenta la motivación", "Mejora la coordinación", "Genera compromiso"],
    },
    {
      title: "Roles Definidos",
      description: "Clarificar responsabilidades y expectativas",
      icon: Puzzle,
      color: "text-primary-600",
      benefits: [
        "Evita duplicación de esfuerzos",
        "Aumenta la eficiencia",
        "Reduce conflictos",
        "Mejora la rendición de cuentas",
      ],
    },
    {
      title: "Apoyo Mutuo",
      description: "Ayudarse mutuamente para alcanzar el éxito",
      icon: Heart,
      color: "text-secondary-600",
      benefits: ["Fortalece relaciones", "Aumenta la resiliencia", "Mejora el clima laboral", "Potencia resultados"],
    },
  ]

  const stages = [
    {
      stage: "Formación",
      description: "Los miembros se conocen y establecen normas básicas",
      characteristics: ["Cortesía", "Expectativas altas", "Ansiedad", "Dependencia del líder"],
      focus: "Establecer confianza y clarificar objetivos",
    },
    {
      stage: "Conflicto",
      description: "Surgen diferencias y se definen roles de poder",
      characteristics: ["Tensión", "Competencia", "Resistencia", "Formación de subgrupos"],
      focus: "Resolver conflictos y establecer normas de trabajo",
    },
    {
      stage: "Normalización",
      description: "Se establecen normas y se desarrolla cohesión",
      characteristics: ["Cooperación", "Normas claras", "Identidad grupal", "Confianza"],
      focus: "Desarrollar procedimientos y fortalecer relaciones",
    },
    {
      stage: "Desempeño",
      description: "El equipo funciona eficientemente hacia sus objetivos",
      characteristics: ["Alta productividad", "Flexibilidad", "Innovación", "Autonomía"],
      focus: "Mantener el rendimiento y la mejora continua",
    },
  ]

  const roles = [
    {
      role: "Coordinador",
      description: "Organiza actividades y facilita la comunicación",
      skills: ["Organización", "Comunicación", "Planificación"],
    },
    {
      role: "Motivador",
      description: "Mantiene el ánimo y la moral del grupo",
      skills: ["Empatía", "Positividad", "Inspiración"],
    },
    {
      role: "Analista",
      description: "Evalúa opciones y proporciona análisis crítico",
      skills: ["Pensamiento crítico", "Análisis", "Objetividad"],
    },
    {
      role: "Ejecutor",
      description: "Implementa decisiones y completa tareas",
      skills: ["Disciplina", "Confiabilidad", "Eficiencia"],
    },
    {
      role: "Innovador",
      description: "Genera ideas creativas y soluciones nuevas",
      skills: ["Creatividad", "Flexibilidad", "Visión"],
    },
    {
      role: "Mediador",
      description: "Resuelve conflictos y mantiene la armonía",
      skills: ["Diplomacia", "Paciencia", "Negociación"],
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Trabajo en Equipo</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          El trabajo en equipo efectivo es la base del éxito en los créditos grupales. Aprende a colaborar, comunicarte
          y crear sinergia con tu grupo.
        </p>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <CardTitle className="text-xl text-center text-primary-900">La Sinergia: 1 + 1 = 3</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-primary-800">
            Un equipo efectivo logra resultados que superan la suma de los esfuerzos individuales. En los créditos
            grupales, esta sinergia es fundamental para el éxito financiero y social de todos los miembros.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {principles.map((principle, index) => {
          const Icon = principle.icon
          return (
            <Card key={index}>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Icon className={`h-6 w-6 ${principle.color}`} />
                  <div>
                    <CardTitle className="text-lg">{principle.title}</CardTitle>
                    <p className="text-sm text-gray-600">{principle.description}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-semibold mb-2 text-gray-700">Beneficios:</h4>
                <ul className="space-y-1">
                  {principle.benefits.map((benefit, benefitIndex) => (
                    <li key={benefitIndex} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2"></span>
                      <span className="text-sm text-gray-600">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Etapas del Desarrollo de Equipos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {stages.map((stage, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-lg">{stage.stage}</h4>
                  <Badge variant="outline">Etapa {index + 1}</Badge>
                </div>
                <p className="text-gray-600 mb-3">{stage.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h5 className="font-semibold text-sm text-primary-700 mb-2">Características:</h5>
                    <div className="flex flex-wrap gap-1">
                      {stage.characteristics.map((char, charIndex) => (
                        <Badge key={charIndex} variant="secondary" className="text-xs">
                          {char}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h5 className="font-semibold text-sm text-secondary-700 mb-2">Enfoque:</h5>
                    <p className="text-sm text-gray-600">{stage.focus}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Roles en el Equipo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {roles.map((role, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Award className="h-5 w-5 text-primary-600" />
                  <h4 className="font-semibold">{role.role}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-3">{role.description}</p>
                <div>
                  <h5 className="font-semibold text-xs text-secondary-700 mb-1">Habilidades clave:</h5>
                  <div className="flex flex-wrap gap-1">
                    {role.skills.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Estrategias para Fortalecer el Equipo</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-sm">Realizar reuniones regulares y estructuradas</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-sm">Celebrar logros y reconocer contribuciones</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-sm">Establecer normas claras de comportamiento</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-sm">Fomentar la participación de todos los miembros</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-sm">Desarrollar actividades de integración</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Señales de un Equipo Exitoso</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-sm">Comunicación fluida y respetuosa</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-sm">Cumplimiento consistente de compromisos</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-sm">Resolución constructiva de conflictos</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-sm">Apoyo mutuo en momentos difíciles</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-sm">Logro consistente de objetivos grupales</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3">🤝 Aplicación en Créditos Grupales</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-blue-800">Responsabilidad Compartida</h4>
            <p className="text-sm text-blue-700">Todos los miembros se comprometen con el éxito del grupo</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Apoyo en Crisis</h4>
            <p className="text-sm text-blue-700">El equipo se une para ayudar a miembros con dificultades</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Toma de Decisiones</h4>
            <p className="text-sm text-blue-700">Decisiones grupales sobre nuevos miembros y políticas</p>
          </div>
          <div>
            <h4 className="font-semibold text-blue-800">Crecimiento Conjunto</h4>
            <p className="text-sm text-blue-700">Compartir conocimientos y oportunidades de negocio</p>
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Aprender sobre Créditos
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
