"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Heart, Users, Target, Briefcase, UserCheck } from "lucide-react"

interface WelcomeSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function WelcomeSection({ onComplete, onNext }: WelcomeSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          ¡Bienvenido/a al Equipo de COOPERATIVA OPORTUNIDADES! 🎉
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Estamos emocionados de tenerte como nuevo asesor de crédito en nuestra cooperativa. Este portal te guiará a
          través de todo lo que necesitas saber para comenzar tu carrera profesional con nosotros y brindar el mejor
          servicio a nuestras socias.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Heart className="h-6 w-6 text-secondary-500" />
              <CardTitle className="text-xl">Nuestra Misión</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Brindar oportunidades de crecimiento económico y social a nuestras socias a través de servicios
              financieros accesibles y programas de desarrollo comunitario, con el apoyo de asesores comprometidos.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Target className="h-6 w-6 text-primary-500" />
              <CardTitle className="text-xl">Tu Rol como Asesor</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600">
              Ser el puente entre la cooperativa y nuestras socias, brindando asesoría financiera personalizada,
              evaluando solicitudes de crédito y acompañando el crecimiento de sus emprendimientos.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gradient-to-r from-primary-50 to-secondary-50 border-primary-200">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Briefcase className="h-6 w-6 text-primary-600" />
            <CardTitle className="text-xl text-primary-900">Competencias del Asesor de Crédito</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                <UserCheck className="h-6 w-6 text-primary-600" />
              </div>
              <h4 className="font-semibold text-primary-900">Evaluación</h4>
              <p className="text-sm text-primary-700">Analizar la capacidad de pago y riesgo crediticio</p>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                <Users className="h-6 w-6 text-primary-600" />
              </div>
              <h4 className="font-semibold text-primary-900">Asesoría</h4>
              <p className="text-sm text-primary-700">Guiar a las socias en sus decisiones financieras</p>
            </div>
            <div className="text-center">
              <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                <Heart className="h-6 w-6 text-primary-600" />
              </div>
              <h4 className="font-semibold text-primary-900">Acompañamiento</h4>
              <p className="text-sm text-primary-700">Seguimiento continuo del desarrollo de los negocios</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-yellow-800 mb-2">📋 ¿Qué aprenderás en esta capacitación?</h3>
        <ul className="space-y-2 text-secondary-700">
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-secondary-500 rounded-full"></span>
            <span>Metodología de créditos grupales y evaluación de riesgo</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-secondary-500 rounded-full"></span>
            <span>Técnicas de comunicación y negociación con clientes</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-secondary-500 rounded-full"></span>
            <span>Herramientas para el análisis financiero y seguimiento</span>
          </li>
          <li className="flex items-center space-x-2">
            <span className="w-2 h-2 bg-secondary-500 rounded-full"></span>
            <span>Procedimientos operativos y sistemas de la cooperativa</span>
          </li>
        </ul>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Comenzar mi Capacitación
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
