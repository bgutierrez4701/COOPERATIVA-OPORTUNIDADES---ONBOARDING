"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Users, Target, Heart, Award, Shield, Handshake } from "lucide-react"

interface WhoWeAreSectionProps {
  onComplete: () => void
  onNext: () => void
}

export default function WhoWeAreSection({ onComplete, onNext }: WhoWeAreSectionProps) {
  const handleContinue = () => {
    onComplete()
    onNext()
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Quiénes Somos?</h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          COOPERATIVA OPORTUNIDADES es una institución financiera cooperativa comprometida con el desarrollo económico y
          social de nuestros socios y sus comunidades.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-primary-50 to-primary-100 border-primary-200">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <Target className="h-8 w-8 text-primary-600" />
              <CardTitle className="text-xl text-primary-900">Nuestra Misión</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-primary-800">
              Brindar servicios financieros accesibles y de calidad, especialmente créditos grupales, que generen
              oportunidades reales de crecimiento económico para nuestros socios, fortaleciendo el tejido social y
              promoviendo el desarrollo sostenible de las comunidades.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-secondary-50 to-secondary-100 border-secondary-200">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <Heart className="h-8 w-8 text-secondary-600" />
              <CardTitle className="text-xl text-secondary-900">Nuestra Visión</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-secondary-800">
              Ser la cooperativa líder en microfinanzas y créditos grupales en la región, reconocida por transformar
              vidas a través de oportunidades financieras inclusivas y programas de desarrollo integral.
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center space-x-3">
            <Users className="h-6 w-6 text-primary-600" />
            <CardTitle className="text-2xl">Nuestros Valores Cooperativos</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Handshake className="h-8 w-8 text-primary-600" />
              </div>
              <h4 className="font-semibold text-lg mb-2">Solidaridad</h4>
              <p className="text-gray-600">
                Trabajamos unidos para el bienestar común, apoyándonos mutuamente en el crecimiento económico.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-secondary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-secondary-600" />
              </div>
              <h4 className="font-semibold text-lg mb-2">Responsabilidad</h4>
              <p className="text-gray-600">
                Asumimos nuestros compromisos con seriedad y transparencia hacia nuestros socios y la comunidad.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-primary-600" />
              </div>
              <h4 className="font-semibold text-lg mb-2">Excelencia</h4>
              <p className="text-gray-600">
                Buscamos la mejora continua en nuestros servicios para ofrecer la mejor experiencia a nuestros socios.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">¿Qué nos hace diferentes?</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Enfoque en créditos grupales y metodología solidaria</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Tasas de interés competitivas y accesibles</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Capacitación continua en habilidades financieras</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Acompañamiento personalizado a cada socio</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Nuestro Compromiso</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Generar oportunidades reales de crecimiento</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Fortalecer el desarrollo comunitario</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Promover la inclusión financiera</span>
              </li>
              <li className="flex items-start space-x-3">
                <span className="w-2 h-2 bg-secondary-500 rounded-full mt-2"></span>
                <span className="text-gray-700">Mantener transparencia en todas nuestras operaciones</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-center pt-6">
        <Button onClick={handleContinue} size="lg" className="px-8">
          Conocer Nuestra Historia
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
