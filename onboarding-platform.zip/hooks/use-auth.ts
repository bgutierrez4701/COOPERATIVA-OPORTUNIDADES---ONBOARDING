"use client"

import { useEffect, useState } from "react"
import type { User } from "@supabase/supabase-js"
import { supabase, isSupabaseConfigured, type Profile } from "@/lib/supabase"

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isSupabaseConfigured) {
      // Demo mode - create a mock admin user
      const mockUser = {
        id: "demo-admin-id",
        email: "admin@coopoportunidades.com",
        created_at: new Date().toISOString(),
      } as User

      const mockProfile: Profile = {
        id: "demo-admin-id",
        email: "admin@coopoportunidades.com",
        full_name: "Administrador Demo",
        role: "admin",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      setUser(mockUser)
      setProfile(mockProfile)
      setLoading(false)
      return
    }

    // Obtener sesión inicial
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchProfile(session.user.id)
      } else {
        setLoading(false)
      }
    })

    // Escuchar cambios de autenticación
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchProfile(session.user.id)
      } else {
        setProfile(null)
        setLoading(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const fetchProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

      if (error) throw error
      setProfile(data)
    } catch (error) {
      console.error("Error fetching profile:", error)
    } finally {
      setLoading(false)
    }
  }

  const signIn = async (email: string, password: string) => {
    if (!isSupabaseConfigured) {
      // Demo mode - simulate login
      if (email === "admin@coopoportunidades.com" && password === "admin123") {
        return { data: { user: { id: "demo-admin-id", email } }, error: null }
      } else if (email === "usuario@coopoportunidades.com" && password === "user123") {
        const mockUser = {
          id: "demo-user-id",
          email: "usuario@coopoportunidades.com",
          created_at: new Date().toISOString(),
        } as User

        const mockProfile: Profile = {
          id: "demo-user-id",
          email: "usuario@coopoportunidades.com",
          full_name: "Usuario Demo",
          role: "user",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        setUser(mockUser)
        setProfile(mockProfile)
        return { data: { user: mockUser }, error: null }
      } else {
        return { data: null, error: { message: "Credenciales incorrectas" } }
      }
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    return { data, error }
  }

  const signOut = async () => {
    if (!isSupabaseConfigured) {
      setUser(null)
      setProfile(null)
      return { error: null }
    }

    const { error } = await supabase.auth.signOut()
    return { error }
  }

  const isAdmin = profile?.role === "admin"

  return {
    user,
    profile,
    loading,
    signIn,
    signOut,
    isAdmin,
    isSupabaseConfigured,
  }
}
