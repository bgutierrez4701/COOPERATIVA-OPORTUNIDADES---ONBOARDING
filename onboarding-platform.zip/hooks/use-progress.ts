"use client"

import { useEffect, useState } from "react"
import { supabase, isSupabaseConfigured, type UserProgress } from "@/lib/supabase"
import { useAuth } from "./use-auth"

export function useProgress() {
  const { user } = useAuth()
  const [progress, setProgress] = useState<UserProgress[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchProgress()
    }
  }, [user])

  const fetchProgress = async () => {
    if (!user) return

    if (!isSupabaseConfigured) {
      // Demo mode - use localStorage
      const savedProgress = localStorage.getItem(`progress_${user.id}`)
      if (savedProgress) {
        setProgress(JSON.parse(savedProgress))
      }
      setLoading(false)
      return
    }

    try {
      const { data, error } = await supabase.from("user_progress").select("*").eq("user_id", user.id)

      if (error) throw error
      setProgress(data || [])
    } catch (error) {
      console.error("Error fetching progress:", error)
    } finally {
      setLoading(false)
    }
  }

  const completeModule = async (moduleId: number) => {
    if (!user) return

    if (!isSupabaseConfigured) {
      // Demo mode - use localStorage
      const newProgress: UserProgress = {
        id: `demo-${moduleId}`,
        user_id: user.id,
        module_id: moduleId,
        completed: true,
        completed_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
      }

      const updatedProgress = [...progress.filter((p) => p.module_id !== moduleId), newProgress]
      setProgress(updatedProgress)
      localStorage.setItem(`progress_${user.id}`, JSON.stringify(updatedProgress))
      return
    }

    try {
      const { error } = await supabase.from("user_progress").upsert({
        user_id: user.id,
        module_id: moduleId,
        completed: true,
        completed_at: new Date().toISOString(),
      })

      if (error) throw error
      await fetchProgress()
    } catch (error) {
      console.error("Error completing module:", error)
    }
  }

  const getCompletedModules = () => {
    return progress.filter((p) => p.completed).map((p) => p.module_id)
  }

  return {
    progress,
    loading,
    completeModule,
    getCompletedModules,
  }
}
